{
  name: "cerulite",
  spritenum: 666,
  megaStone: "Ceruledge-Mega",
  megaEvolves: ["Ceruledge"],
  itemUser: ["Ceruledge"],
  onTakeItem(item, source) {
    if (item.megaEvolves === source.baseSpecies.baseSpecies) return false;
    return true;
  },
  num: -999,
  gen: 5,
  isNonstandard: "Past",
}