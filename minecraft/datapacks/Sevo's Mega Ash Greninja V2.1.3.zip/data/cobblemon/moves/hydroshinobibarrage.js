{
  num: 999,
  accuracy: true,
  basePower: 30,
  category: "Special",
  isNonstandard: "Past",
  name: "Hydro Shinobi Barrage",
  pp: 1,
  priority: 0,
  flags: {bypasssub: 1},
  willCrit: true,
  ignoreAbility: true,
  multihit: [5],
  onModifyMove(move, pokemon) {
    if (pokemon.getStat("atk", false, true) > pokemon.getStat("spa", false, true))
      move.category = "Physical";
  },
  isZ: "ashgreninjitez",
  secondary: null,
  target: "normal",
  type: "Water",
  contestType: "Cool"
}