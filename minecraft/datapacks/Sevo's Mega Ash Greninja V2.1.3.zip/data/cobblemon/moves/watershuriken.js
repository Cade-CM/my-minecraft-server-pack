{
  num: 594,
  accuracy: 100,
  basePower: 15,
  category: "Special",
  name: "Water Shuriken",
  pp: 20,
  priority: 1,
  flags: { protect: 1, mirror: 1, metronome: 1 },
  multihit: [2, 5],
	onModifyMove(move, pokemon) {
	  if (pokemon.species.name === "Greninja-Ash" && pokemon.hasAbility("battlebond") && !pokemon.transformed) {	
		move.multihit = [3, 5];
	  }
  },
  onModifyMove(move, pokemon) {
    if (pokemon.species.name === "Greninja-Mega-Ash" && pokemon.hasAbility("unseenshinobi") && !pokemon.transformed) {	
      move.multihit = [3, 5];
      move.critRatio = 2;
      move.priority = 2;
      if (pokemon.getStat("atk", false, true) > pokemon.getStat("spa", false, true)) move.category = "Physical";
    }
  },
  basePowerCallback(pokemon, target, move) {
    if (pokemon.species.name === "Greninja-Ash" && pokemon.hasAbility("battlebond") && !pokemon.transformed) {	
      return move.basePower + 5;
    }
    if (pokemon.species.name === "Greninja-Mega-Ash" && pokemon.hasAbility("unseenshinobi") && !pokemon.transformed) {	
      return move.basePower + 5;
    }
    return move.basePower;
  },
  secondary: null,
  target: "normal",
  type: "Water",
  contestType: "Cool"
}