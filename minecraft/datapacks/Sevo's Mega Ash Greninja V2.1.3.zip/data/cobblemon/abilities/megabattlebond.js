{
  onSourceAfterFaint(length, target, source, effect) {
    if (effect?.effectType !== "Move")
      return;
    if (source.abilityState.battleBondTriggered)
      return;
    if (source.species.id === "greninjamegabond" && source.hp && source.side.foePokemonLeft()) {
      source.formeChange("Greninja-Mega-Ash", this.effect, true, "[msg]");
      this.add("-activate", source, "ability: Mega Battle Bond");
      this.boost({ atk: 1, spa: 1, spe: 1 }, source, source, this.effect);
      source.abilityState.battleBondTriggered = true;
    }
  },
  flags: { failroleplay: 1, noreceiver: 1, noentrain: 1, notrace: 1, failskillswap: 1, cantsuppress: 1 },
  name: "Mega Battle Bond",
  rating: 3.5,
  num: 777
}