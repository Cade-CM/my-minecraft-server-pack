{
  onModifyMove(move, pokemon) {
		if (!move.flags["contact"]) {
			delete move.flags["protect"];
		}
	},
	flags: {},
	name: "Unseen Shinobi",
	rating: 4.5,
	num: 998
}
