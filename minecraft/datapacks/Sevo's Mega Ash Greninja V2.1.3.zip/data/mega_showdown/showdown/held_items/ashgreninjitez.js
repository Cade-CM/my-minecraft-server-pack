{
  name: "Ash Greninjite Z",
  spritenum: 999,
  megaStone: "Greninja-Mega-Bond",
  megaEvolves: ["Greninja-Bond"],
  itemUser: ["Greninja-Bond"],
  onModifyAtkPriority: 1,
  onModifyAtk(atk, pokemon) {
    if (pokemon.species.name === "Greninja-Bond") {
      return this.chainModify(1.1);
    }
  },
  onModifyAtkPriority: 1,
  onModifySpA(spa, pokemon) {
    if (pokemon.species.name === "Greninja-Bond") {
      return this.chainModify(1.1);
    }
  },
  onTakeItem(item, source) {
    if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
    return true;
  },
  num: -999,
  gen: 6,
  isNonstandard: "Past",
}